import 'package:flutter/material.dart'; // Import package flutter/material.dart untuk mengakses widget Flutter
import 'dart:convert'; // Import library dart:convert untuk mengkonversi JSON

void main() {
  runApp(const MyApp()); // Fungsi main() untuk menjalankan aplikasi Flutter
}

// Deklarasi kelas MataKuliah dengan atribut kode, nama, sks, dan nilai
class MataKuliah {
  final String kode;
  final String nama;
  final int sks;
  final String nilai;

  MataKuliah({
    required this.kode,
    required this.nama,
    required this.sks,
    required this.nilai,
  });

  // Konstruktor factory untuk membuat instance MataKuliah dari JSON
  factory MataKuliah.fromJson(Map<String, dynamic> json) {
    return MataKuliah(
      kode: json['kode'],
      nama: json['nama'],
      sks: json['sks'],
      nilai: json['nilai'],
    );
  }
}

// Deklarasi kelas TranskripMahasiswa dengan atribut nama, nim, programStudi, dan mataKuliah
class TranskripMahasiswa {
  final String nama;
  final String nim;
  final String programStudi;
  final List<MataKuliah> mataKuliah;

  TranskripMahasiswa({
    required this.nama,
    required this.nim,
    required this.programStudi,
    required this.mataKuliah,
  });

  // Konstruktor factory untuk membuat instance TranskripMahasiswa dari JSON
  factory TranskripMahasiswa.fromJson(Map<String, dynamic> json) {
    List<dynamic> mataKuliahJson = json['mata_kuliah'];
    List<MataKuliah> mataKuliahList =
        mataKuliahJson.map((item) => MataKuliah.fromJson(item)).toList();

    return TranskripMahasiswa(
      nama: json['nama'],
      nim: json['nim'],
      programStudi: json['program_studi'],
      mataKuliah: mataKuliahList,
    );
  }
}

// Fungsi hitungIPK untuk menghitung Indeks Prestasi Kumulatif (IPK) berdasarkan nilai mata kuliah
double hitungIPK(List<MataKuliah> mataKuliah) {
  double totalSks = 0;
  double totalBobot = 0;

  for (var matkul in mataKuliah) {
    double sks = matkul.sks.toDouble();
    String nilai = matkul.nilai;
    double bobot;

    // Penentuan bobot berdasarkan nilai
    if (nilai == 'A') {
      bobot = 4.0;
    } else if (nilai == 'A-') {
      bobot = 3.7;
    } else if (nilai == 'B+') {
      bobot = 3.3;
    } else if (nilai == 'B') {
      bobot = 3.0;
    } else if (nilai == 'B-') {
      bobot = 2.7;
    } else if (nilai == 'C+') {
      bobot = 2.3;
    } else if (nilai == 'C') {
      bobot = 2.0;
    } else if (nilai == 'C-') {
      bobot = 1.7;
    } else if (nilai == 'D+') {
      bobot = 1.3;
    } else if (nilai == 'D') {
      bobot = 1.0;
    } else {
      bobot = 0.0;
    }

    totalSks += sks;
    totalBobot += sks * bobot;
  }

  return totalBobot / totalSks; // Mengembalikan nilai IPK
}

// Kelas MyApp sebagai StatefulWidget untuk menampilkan data transkrip mahasiswa
class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return MyAppState();
  }
}

// Kelas MyAppState sebagai state dari MyApp
class MyAppState extends State<MyApp> {
  late TranskripMahasiswa
      transkripMahasiswa; // Deklarasi variabel transkripMahasiswa

  @override
  void initState() {
    super.initState();

    // String JSON yang menunjukkan data transkrip mahasiswa
    String jsonString = '''
    {
      "nama": "Arisa Rizatul Zahra",
      "nim": "22082010055",
      "program_studi": "Sistem Informasi",
      "mata_kuliah": [
        {
          "kode": "INF101",
          "nama": "Pemrograman Dasar",
          "sks": 3,
          "nilai": "A"
        },
        {
          "kode": "INF102",
          "nama": "Algoritma dan Struktur Data",
          "sks": 4,
          "nilai": "B+"
        },
        {
          "kode": "INF103",
          "nama": "Basis Data",
          "sks": 3,
          "nilai": "A-"
        }
      ]
    }
    ''';

    Map<String, dynamic> jsonMap = json.decode(jsonString);
    transkripMahasiswa = TranskripMahasiswa.fromJson(
        jsonMap); // Mengisi data transkrip mahasiswa dari JSON
  }

  @override
  Widget build(Object context) {
    double ipk = hitungIPK(transkripMahasiswa.mataKuliah); // Menghitung IPK

    // Memulai aplikasi Flutter dengan MaterialApp
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Hitung IPK Mahasiswa'), // Judul aplikasi
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                  'Nama: ${transkripMahasiswa.nama}'), // Tampilan nama mahasiswa
              Text('NIM: ${transkripMahasiswa.nim}'), // Tampilan NIM mahasiswa
              Text(
                  'Program Studi: ${transkripMahasiswa.programStudi}'), // Tampilan program studi mahasiswa
              Text('IPK: ${ipk.toStringAsFixed(2)}'), // Tampilan IPK mahasiswa
            ],
          ),
        ),
      ),
    );
  }
}
