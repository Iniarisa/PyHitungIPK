package com.example.transkip

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
