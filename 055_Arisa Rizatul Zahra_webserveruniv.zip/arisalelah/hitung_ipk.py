import 'dart:convert';

void main() {
  String transkripJson = '''
  {
    "nama": "Budi Martami",
    "nim": "123456789",
    "program_studi": "Informatika",
    "transkrip": [
      {
        "mata_kuliah": "Pemrograman Dasar",
        "kode_mata_kuliah": "CS101",
        "sks": 3,
        "nilai": "A"
      },
      {
        "mata_kuliah": "Struktur Data",
        "kode_mata_kuliah": "CS201",
        "sks": 4,
        "nilai": "B+"
      },
      {
        "mata_kuliah": "Algoritma dan Kompleksitas",
        "kode_mata_kuliah": "CS301",
        "sks": 4,
        "nilai": "A-"
      }
    ]
  }
  ''';

  Map<String, dynamic> transkripMap = jsonDecode(transkripJson);
  List<dynamic> transkrip = transkripMap['transkrip'];

  double totalSKS = 0;
  double totalBobotNilai = 0;

  for (var mataKuliah in transkrip) {
    double sks = double.parse(mataKuliah['sks'].toString());
    totalSKS += sks;

    String nilai = mataKuliah['nilai'];
    double bobotNilai = 0;

    if (nilai == "A") {
      bobotNilai = 4.0;
    } else if (nilai == "A-") {
      bobotNilai = 3.7;
    } else if (nilai == "B+") {
      bobotNilai = 3.3;
    } // tambahkan kondisi untuk nilai lain jika diperlukan

    totalBobotNilai += bobotNilai * sks;
  }

  double ipk = totalBobotNilai / totalSKS;
  print('IPK: $ipk');
}
